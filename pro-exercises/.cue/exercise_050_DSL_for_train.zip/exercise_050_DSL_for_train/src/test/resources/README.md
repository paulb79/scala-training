dsl-for-train

# Exercise 50 > DSL for Train

- Create a DSL which lets you create Trains like this:

```scala
     InterCityExpress(724) at
       8 :: 50 from "Munich" at
       "10:00" from "Nuremberg"

     InterCityExpress(724) at
       8 :: 50 from "Munich" at
       "10:00" from "Nuremberg" at
       12 :: 10 from "Frankfurt"
```

- Again, don't change the `Train` class itself, but add the DSL as a separate layer

- Make sure you make the `Train` DSL robust, e.g. make it impossible to create a `Train`
  with only one schedule element

- Use the `nextExercise` command to move to the next exercise.