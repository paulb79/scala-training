group-exercise-custom-control-abstractions

# Exercise 47 > Group Exercise - Custom control abstractions

- Let's create a custom control abstraction for automated resource management
  (ARM)

- A resource is "something that can be closed"

- The "new keyword" `withResource` shall close the given resource automatically

- Usage example:

```scala
     scala> withResource(in) { resource =>
          |   Source.fromInputStream(resource).getLines.size
          | }
     res0: Int = 10
```

- Use the `nextExercise` command to move to the next exercise.