extend-my-library

# Exercise 43 > Extend my library

- The `==` operator is not typesafe, i.e. compares against `Any`

- Wouldn't a typesafe `===` operator be nice?

```scala
    1 === 1      // true
    "a" === "b"  // false
    1 === "1"    // Won’t compile
```

- Create the `Equal` singleton object in the misc package

- Create the implicit class `EqualOps` in the `Equal` singleton object:

- Add a polymorphic and typesafe `===` operator which delegates to the "natural"
  equality `==`

- Create the class `EqualSpec` verifying that `===` works as expected

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.