implicit-conversions-I

# Exercise 41 > Implicit Conversions I

- In ScalaTrain we often need Stations, which just wrap a String

- Wouldn't using Strings directly be more convenient?

```scala
    planner trainsAt "Munich"
```

- Create an implicit conversion from `String` to `Station`

- Use the `test` command to verify the solution works as expected.

- Also give it a try in the REPL

- Use the `nextExercise` command to move to the next exercise.