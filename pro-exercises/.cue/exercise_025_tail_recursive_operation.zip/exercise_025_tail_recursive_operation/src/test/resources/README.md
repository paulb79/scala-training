tail-recursive-operation

# Exercise 25 > Tail recursive operation

- Add an `isIncreasing` method to the `Time` companion object

  - Add a parameter of type immutable `Seq` of `Time`
  - Return true only if the given times are strictly increasing
  - Implement the method in a tail recursive fashion

- Do you remember the `TODO` comment in `Train`?

  - Use `Time.isIncreasing` to verify that `Train.schedule` is strictly 
    increasing in time
  - Add a test for this precondition to `TrainSpec`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.