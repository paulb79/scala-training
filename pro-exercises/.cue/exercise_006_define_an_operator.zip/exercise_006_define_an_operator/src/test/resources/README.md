define-an-operator

# Exercise 6 > Define an Operator

- Add a `-` method to `Time`

- Make it an alias of `minus`, i.e. delegate to `minus`

- Call the `-` operator in the REPL

- Also call the `minus` method in infix operator notation

- Use the `nextExercise` command to move to the next exercise.