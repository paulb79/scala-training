lower-bounds

# Exercise 37 > Lower Bounds

- Add an `enqueue` method to `Queue`
  - Add a parameter of a suitable type (`A` does not work) for a new element to
    be enqueued
  - Return a new `Queue` with the new element enqueued at the end
  - Hint: Use a lower bounded type parameter at the method level

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.