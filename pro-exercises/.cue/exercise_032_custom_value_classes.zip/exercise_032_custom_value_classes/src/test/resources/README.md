custom-value-classes

# Exercise 32 > Custom Value Classes

- Inspect the byte code of a method with a parameter of type `Station`

- Make `Station` a custom value class

- Inspect the byte code once again and see the difference

- Use the `nextExercise` command to move to the next exercise.