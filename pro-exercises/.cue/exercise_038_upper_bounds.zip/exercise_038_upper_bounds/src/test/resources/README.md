upper-bounds

# Exercise 38 > Upper Bounds

- There is no reason, why the `isIncreasing` and `isIncreasingSliding` methods
  should be restricted to `Time`

- Create the package object `com.lightbend.training.scalatrain` and move these
  methods there

- Finally make these methods work with any sequence of `Ordered` elements

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.