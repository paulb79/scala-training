context-bounds

# Exercise 46 > Context bounds

- There is no reason, why the `isIncreasing`* methods should be restricted to
  `Ordered` elements

- Let's use context bounds and type classes instead

  *Tip*: Have a look at the more general `scala.math.Ordering`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.