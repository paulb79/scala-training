/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package misc

import org.scalatest.{ Matchers, WordSpec }

class QueueSpec extends WordSpec with Matchers {

  "Calling equals" should {
    "be true for identical objects" in {
      val queue = new Queue(List(1, 2, 3))
      queue == queue shouldBe true
    }
    "be true for equal objects" in {
      new Queue(List(1, 2, 3)) == new Queue(List(1, 2, 3)) shouldBe true
    }
    "be false for nonequal objects" in {
      new Queue(List(1, 2)) == new Queue(List(1, 2, 3)) shouldBe false
    }
  }

  "Calling hashCode" should {
    "return the same value for equal objects" in {
      new Queue(List(1, 2, 3)).## shouldEqual new Queue(List(1, 2, 3)).##
    }
  }

  "Calling toString" should {
    "return the class name and the elements in parentheses" in {
      new Queue(List(1, 2, 3)).toString shouldEqual "Queue(1, 2, 3)"
    }
  }

}
