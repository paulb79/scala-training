create-a-queue-I

# Exercise 33 > Create a queue - I

- The standard library contains a `Queue` class, but we will write our own from
  scratch

- Create the `Queue` class in the misc package

  - Add an `A` type parameter and an `elements` class parameter of type
    immutable `Seq` of `A`
  - Override `equals` and `hashCode` delegating to `elements`
  - Override `toString` in case class fashion

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.