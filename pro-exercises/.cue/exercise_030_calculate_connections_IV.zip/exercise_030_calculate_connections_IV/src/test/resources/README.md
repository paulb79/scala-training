calculate-connections-IV

# Exercise 30 > Calculate connections IV

- Next add an immutable `hops` field to `JourneyPlanner`
  - Use an immutable Map of `Station` and `Set[Hop]` for the type
    - Initialize it with all `Hop`s grouped by their departure `Station`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.