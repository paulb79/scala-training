custom-control-abstractions

# Exercise 48 > Custom control abstractions

- **Attention**: Don't use Scala's `while` for the following

- Create a `repeatWhile` loop which can be used like this:

```scala
     var x = 0
     repeatWhile(x < 5) {
       println(x)
       x += 1
     }
```

- Get some bonus points by creating a `repeat-until` loop:

```scala
     var x = 0
     repeat {
       println(x)
       x += 1
     } until(x >= 5)
```

- Use the `nextExercise` command to move to the next exercise.