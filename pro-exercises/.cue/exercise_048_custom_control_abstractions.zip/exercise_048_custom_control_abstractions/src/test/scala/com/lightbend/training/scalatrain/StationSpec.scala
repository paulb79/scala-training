/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

import org.scalatest.{ Matchers, WordSpec }

class StationSpec extends WordSpec with Matchers {

  "Implicitly converting a String into a Station" should {
    "create a properly initialized Station" in {
      val name = "Munich"
      (name: Station).name shouldEqual name
    }
  }
}
