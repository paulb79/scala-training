use-map

# Exercise 14 > Use map

- Change the type of `Train.schedule` to an immutable `Seq[(Time, Station)]`
  - Add a `TODO` comment: Verify that `schedule` is strictly increasing in time

- Add a `stations` field to `Train`

  - Use an immutable `Seq` of `Station` for the type
  - Initialize it with all `Stations` contained in `schedule`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.