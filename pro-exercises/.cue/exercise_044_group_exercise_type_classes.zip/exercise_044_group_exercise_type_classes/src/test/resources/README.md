group-exercise-type-classes

# Exercise 44 > Group Exercise - Type classes

- Let's clean up `JSON` serialization for `Time`:
  - The `toJson` method is too specific to be part of the API

- Let's use `Play`'s implicit format for the serialization

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.