/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

import scala.collection.immutable.Seq

object TrainDSL {

  implicit class TrainOps(val train: Train) extends AnyVal {

    def at(time: Time): TrainFromOps =
      new TrainFromOps(train.info, train.schedule, time)
  }

  implicit class TrainInfoOps(val info: TrainInfo) extends AnyVal {

    def at(time: Time): TrainInfoFromOps =
      new TrainInfoFromOps(info, time)
  }

  class TrainFromOps private[TrainDSL] (info: TrainInfo, schedule: Seq[(Time, Station)], time: Time) {

    def from(station: Station): Train =
      new Train(info, schedule :+ time -> station)
  }

  class TrainInfoFromOps private[TrainDSL] (info: TrainInfo, time: Time) {

    def from(station: Station): TrainInfoAtOps =
      new TrainInfoAtOps(info, Vector(time -> station))
  }

  class TrainInfoAtOps private[TrainDSL] (info: TrainInfo, schedule: Seq[(Time, Station)]) {

    def at(time: Time): TrainFromOps =
      new TrainFromOps(info, schedule, time)
  }
}

