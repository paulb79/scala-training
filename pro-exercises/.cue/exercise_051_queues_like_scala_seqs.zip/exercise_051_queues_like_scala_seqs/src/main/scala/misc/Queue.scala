/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package misc

import scala.collection.SeqLike
import scala.collection.immutable.Seq
import scala.collection.mutable.{ Builder, ListBuffer }

object Queue {

  def apply[A](elements: A*): Queue[A] =
    new Queue(elements.toVector)
}

class Queue[+A] private (private val elements: Seq[A]) extends Seq[A] with SeqLike[A, Queue[A]] {

  def dequeue: (A, Queue[A]) =
    elements match {
      case element +: elements => (element, new Queue(elements))
      case _       => throw new UnsupportedOperationException("Cannot dequeue from an empty queue")
    }
  
  def enqueue[B >: A](element: B): Queue[B] =
    new Queue(elements :+ element)

  override def apply(i: Int): A =
    elements(i)

  override def length: Int =
    elements.length

  override def iterator: Iterator[A] =
    elements.iterator

  override protected[this] def newBuilder: Builder[A, Queue[A]] =
    ListBuffer[A]() mapResult (new Queue(_))

  override def equals(other: Any): Boolean =
    other match {
      case that: Queue[_] => (this eq that) || (this.elements == that.elements)
      case _              => false
    }

  override def hashCode: Int =
    elements.hashCode

  override def toString: String =
    s"Queue(${elements mkString ", "})"
}
