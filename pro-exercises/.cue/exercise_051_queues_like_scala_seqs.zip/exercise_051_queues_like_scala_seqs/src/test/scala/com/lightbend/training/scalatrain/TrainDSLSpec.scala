/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

import TestData._
import org.scalatest.{ Matchers, WordSpec }

class TrainDSLSpec extends WordSpec with Matchers {

  import TrainDSL._
  import TimeDSL._

  "Creating a Train starting with a TrainInfo" should {
    "return a properly initialized Train" in {
      (InterCityExpress(724) at "8:50" from "Munich" at "10:00" from "Nuremberg") shouldEqual
        Train(InterCityExpress(724), Vector(ice724MunichTime -> munich, ice724NurembergTime -> nuremberg))
    }
  }

  "Creating a Train starting with a Train" should {
    "return a properly initialized Train" in {
      (InterCityExpress(724) at "8:50" from "Munich" at "10:00" from "Nuremberg" at "12:10" from "Frankfurt") shouldEqual
        Train(InterCityExpress(724), Vector(ice724MunichTime -> munich, ice724NurembergTime -> nuremberg, ice724FrankfurtTime -> frankfurt))
    }
  }
}
