type-classes

# Exercise 45 > Type classes

- Apply the type class pattern to the `===` operator:
  - Create the `Equal[A]` type class declaring an `equal(a1: A, a2: A): Boolean`
    method
  - Add a type class instance for `Int` behaving as expected
  - Add a type class instance for `String` behaving in an inverted fashion

```scala
     1   === 1      // true, as expected
     "a" === "a"    // false, inverted
```

- Get some bonus points by providing an `Equal[Any]` based on natural equality
  that is used as default

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.