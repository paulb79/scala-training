covariance

# Exercise 36 > Covariance

- In the REPL, create the `Animal` class and the `Bird` subclass

- Try to assign a `Queue` of `Bird` to a variable of type `Queue` of `Animal`

- Next make `Queue` covariant in its A type parameter

- Then try the above assignment again

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.