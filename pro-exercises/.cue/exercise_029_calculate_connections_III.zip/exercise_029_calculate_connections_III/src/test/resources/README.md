calculate-connections-III

# Exercise 29 > Calculate connections III

- Next create the `Hop` case class (add it to `JourneyPlanner.scala`)

  - Add the `from` and `to` class parameters of type `Station`,
    which must not be equal
  - Add a `train` class parameter of type `Train`, where `from`
    and `to` must be back-to-back Stations
  - Add checks for the above preconditions
  - Add the immutable `departureTime` and `arrivalTime` fields
    of type `Time`, initialized using `Train.departureTimes`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.  