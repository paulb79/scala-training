use-flatmap

# Exercise 15 > Use flatMap

- Create the `JourneyPlanner` class

  - Add a `trains` class parameter of type `Set` of `Train`

- Add a `stations` field to `JourneyPlanner`

  - Initialize it with all `Stations` of all `Trains`
  - Which type makes sense?

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.