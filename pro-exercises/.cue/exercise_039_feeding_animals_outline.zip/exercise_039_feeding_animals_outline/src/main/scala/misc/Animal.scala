/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package misc

// Animal

abstract class Animal {

  def name: String

  def eat(food: Food): Animal =
    this
}

case class Bird(name: String) extends Animal

case class Cow(name: String) extends Animal

// Food

abstract class Food

case object Grains extends Food

case object Grass extends Food

// Feeding

object FeedingAnimals {

  def main(args: Array[String]): Unit = {

    val bill = Bird("Bill")
    bill eat Grains
    bill eat Grass // Shouldn't compile

    val cindy = Cow("Cindy")
    cindy eat Grass
    cindy eat Grains // Shouldn't compile
  }
}
