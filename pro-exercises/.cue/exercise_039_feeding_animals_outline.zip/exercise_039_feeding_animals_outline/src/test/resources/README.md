feeding-animals-outline

# Exercise 39 > Feeding Animals - Outline

- Pull-in the source template for this exercise by running the following command
  in sbt:

  man [e] > scalatrain > feeding-animals-outline > `pullTemplate scala/misc/Animal.scala`

- Let's have a look at the code in `misc.Animal`

- `Animals` should only be able to eat suitable `Food`:
  - `Birds` eat `Grains`
  - `Cows` eat `Grass`

- Let's enforce that at compile time

- Next let's add `Fish` that eat `Fish`

- Then let's change `Fish` such that they eat all `Food` that can swim

- Finally let's make sure that eating leaves the specific `Animal` unchanged,
  so that `Animals` can eat and eat and ..., i.e. we can chain method calls

- Use the `nextExercise` command to move to the next exercise.