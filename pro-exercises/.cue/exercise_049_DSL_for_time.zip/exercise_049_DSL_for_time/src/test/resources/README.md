group-exercise-dsl-for-time

# Exercise 49 > Group exercise: DSL for Time

- Let's create a `DSL` which lets us create `Time`s like this:

```scala
     scala> 11 am
     res0: Time = 11:00

     scala> 11 :: 30
     res1: Time = 11:30

     scala> 11 :: 30 pm
     res2: Time = 23:30
```

- Don't change the `Time` class itself, but add the `DSL` as a layer on top 
  of the domain objects

- Hint: All we need are operator notation and implicit conversions

- Use the `nextExercise` command to move to the next exercise.