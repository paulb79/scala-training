use-filter

# Exercise 16 > Use filter

- Add a `trainsAt` method to `JourneyPlanner`

  - Add a `station` parameter of type `Station`
  - Return all `Trains` that contain the given `station` in their `stations`
    field
  - Which return type makes sense?

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.