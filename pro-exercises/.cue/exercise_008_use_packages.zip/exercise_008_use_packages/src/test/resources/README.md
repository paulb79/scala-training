use-packages

# Exercise 8 > Use Packages

- From now on we will use specific packages

- Move the `Time` and `Train` classes to the `com.lightbend.training.scalatrain`
  package

    - Either use the "Refactor > Move..." wizard

    - Or add the package clauses manually and move the files to the
      `com/lightbend/training/scalatrain` sub directory of `src/main/scala`

- In `project/AdditionalSettings.scala`, change variable `loadInitialCmds` from
  `false` to `true`, then reload the sbt session

- Create a `Time` in the REPL

- Use the `nextExercise` command to move to the next exercise.