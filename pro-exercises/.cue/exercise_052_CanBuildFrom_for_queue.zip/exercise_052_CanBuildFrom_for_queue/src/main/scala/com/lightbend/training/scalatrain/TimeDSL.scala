/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

object TimeDSL {

  private def am(time: Time): Time = {
    require(time > Time() && time <= Time(12), "time must be (00:00,12:00]!")
    time match {
      case Time(12, 0) => Time()
      case _ => time
    }
  }

  private def pm(time: Time): Time = {
    require(time > Time() && time <= Time(12), "time must be within (00:00,12:00]!")
    if (time != Time(12))
      time.copy(hours = time.hours + 12)
    else
      time
  }

  implicit class IntOps(val n: Int) extends AnyVal {

    def ::(hours: Int): Time =
      Time(hours, n)

    def am: Time =
      TimeDSL.am(Time(n))

    def pm: Time =
      TimeDSL.pm(Time(n))
  }

  implicit class TimeOps(val time: Time) extends AnyVal {

    def am: Time =
      TimeDSL.am(time)

    def pm: Time =
      TimeDSL.pm(time)
  }
}
