CanBuildFrom_for_queue

# Exercise 52 > CanBuildFrom for Queue

*Note* this exercise is optional

- Add a type class instance for `CanBuildFrom` to `Queue`:

- For all `A` and `B` a `Queue[B]` can be built from a `Queue[A]`

- Now the following should also work:

```scala
     scala> Queue(1, 2, 3) map (_ + 1)
     res0: misc.Queue[Int] = Queue(2, 3, 4)
```

- Congratulations! You have reached the end of this course!
