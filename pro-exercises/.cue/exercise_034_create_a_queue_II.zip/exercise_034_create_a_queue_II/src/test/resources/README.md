create-a-queue-II

# Exercise 34 > Create a queue - II

- Create the `Queue` companion object with an apply factory method

  - Which return type makes sense?
  - Add an `A` type parameter and elements repeated parameters of type `A`
  - Return a `Queue` containing all elements

- Make the constructor of `Queue` private

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.