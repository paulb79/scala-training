/*
 * Copyright © 2012 - 2016 Lightbend, Inc. All rights reserved.
 */

package com.lightbend.training.scalatrain

import scala.collection.immutable.Seq

class JourneyPlanner(trains: Set[Train]) {

  val stations: Set[Station] =
    // Could also be expressed in short notation: trains flatMap (_.stations)
    trains.flatMap(train => train.stations)

  val hops: Map[Station, Set[Hop]] = {
    val hops = for {
      train <- trains
      (from, to) <- train.backToBackStations
    } yield Hop(from, to, train)
    hops groupBy (_.from)
  }

  def trainsAt(station: Station): Set[Train] =
    // Could also be expressed in short notation: trains filter (_.stations contains station)
    trains.filter(train => train.stations.contains(station))

  def stopsAt(station: Station): Set[(Time, Train)] =
    for {
      train <- trains
      time <- train.timeAt(station)
    } yield (time, train)

  def isShortTrip(from: Station, to: Station): Boolean =
    trains.exists(train =>
      train.stations.dropWhile(station => station != from) match {
        case `from` +: `to` +: _      => true
        case `from` +: _ +: `to` +: _ => true
        case _                        => false
      }
    )

  def connections(from: Station, to: Station, departureTime: Time): Set[Vector[Hop]] = {
    require(from != to, "from and to must not be equal!")

    @scala.annotation.tailrec
    def connections(foundConnections: Set[Vector[Hop]], searching: Vector[Vector[Hop]]): Set[Vector[Hop]] = {
      searching match {
        case hopsSoFar +: remaining =>
          val lastHop = hopsSoFar.last
          val soFarStations = hopsSoFar.head.from +: hopsSoFar.tail.map(_.to)
          val nextHops = hops.getOrElse(lastHop.to, Set())
            .filter(hop => (hop.departureTime >= lastHop.arrivalTime) && !(soFarStations contains hop.to))
          val (destReachedHops, remHops) = nextHops.partition(hop => hop.to == to)
          val toStationReached = destReachedHops.map(hop => hopsSoFar :+ hop)
          val toStationNotReached = remHops.map(hop => hopsSoFar :+ hop).toVector
          connections(toStationReached ++ foundConnections, toStationNotReached ++ remaining)
        case _ =>
          foundConnections
      }
    }
    val nextHops = hops.getOrElse(from, Set())
      .filter (_.departureTime >= departureTime)
    connections(Set.empty[Vector[Hop]], nextHops.map(hop => Vector(hop)).toVector)
  }

  def connections_alternative(from: Station, to: Station, departureTime: Time): Set[Seq[Hop]] = {
    require(from != to, "from and to must not be equal!")
    def connections(soFar: Vector[Hop]): Set[Vector[Hop]] = {
      if (soFar.last.to == to)
        Set(soFar)
      else {
        val soFarStations = soFar.head.from +: (soFar map (_.to))
        val nextHops = hops.getOrElse(soFar.last.to, Set()) filter (hop =>
          (hop.departureTime >= soFar.last.arrivalTime) && !(soFarStations contains hop.to)
        )
        nextHops flatMap (hop => connections(soFar :+ hop))
      }
    }
    val nextHops = hops.getOrElse(from, Set()) filter (_.departureTime >= departureTime)
    nextHops flatMap (hop => connections(Vector(hop)))
  }
}

case class Hop(from: Station, to: Station, train: Train) {
  require(from != to, "from must not be equal to to")
  require(train.backToBackStations contains from -> to, "from and to must be back-to-back stations of train")

  val departureTime: Time =
    train departureTimes from

  val arrivalTime: Time =
    train departureTimes to
}
