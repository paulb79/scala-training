define-case-classes

# Exercise 11 > Define Case Classes

- Make case classes out of `Time` and `Train`

- Remove `val` from the class parameters, even if it doesn't hurt

- Remove `new` in `Time.fromMinutes`, even if it doesn't hurt

- Try out the various case class features in the REPL

- Use the `nextExercise` command to move to the next exercise.