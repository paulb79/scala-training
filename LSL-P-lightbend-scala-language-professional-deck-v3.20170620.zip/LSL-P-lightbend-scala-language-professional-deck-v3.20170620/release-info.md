# Release-info - FTTS Fast Track to Scala

## 2.0.0

Initial release of this course using the new course management tools
