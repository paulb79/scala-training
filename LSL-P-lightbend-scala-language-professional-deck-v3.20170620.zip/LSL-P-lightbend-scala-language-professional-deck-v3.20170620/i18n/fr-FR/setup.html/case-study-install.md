##Installer le code du projet ScalaTrain
- Téléchargez l'[archive ZIP ScalaTrain](scalatrain.zip) contenant le code du projet.
- Décompressez *scalatrain.zip* sur votre disque local
- *cd* dans le répertoire *scalatrain* ainsi créé
