##Résumé des principales commandes d'Activator

- *exit* quitte la session activator
- *help* liste les commandes disponibles
- *compile* compile le code du projet
- *test:compile* compile le code de test et le code du projet
- *test* execute les tests après avoir compilé les sources de test et du projet
- *console* démarre un *REPL* (console scala interactive)avec les classes du projet disponibles sur le *classpath*
- *run* cherche une application dans le projet et l'execute
- *clean* supprime tout ce qui a pu être généré dans le dossier _target_
- *reload* recharge la session activator
