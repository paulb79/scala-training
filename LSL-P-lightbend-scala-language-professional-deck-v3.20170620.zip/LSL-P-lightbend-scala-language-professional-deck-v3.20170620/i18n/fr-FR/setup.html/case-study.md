#Étude de cas ScalaTrain

![ScalaTrain](images/scala-train.jpeg "scala-train")

- Ce cours contient beaucoup d'exercices
- Le cas d'utilisation derrière les exercices est un planificateur de voyage en train, c'est pourquoi le projet est nommé **ScalaTrain**
- Dans le cadre de ce cours, nous allons commencer à créer ScalaTrain *from scratch*
- Dans le cours **Advanced Scala** vous continuerez de construire le projet, du point où nous nous serons arrêtés.
