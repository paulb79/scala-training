## Familiarisez-vous avec Activator

- Démarrer *activator* vous place dans une **session interactive**
- Si ce n'est pas déjà le cas, placez vous dans le dossier de *scalatrain* avec *cd* et démarrez activator:

```no-highlight
scalatrain$ activator
...
[info] Set current project to scala-train ...
>
```

Regardez le fichier *build.sbt*, c'est le fichier définition du *build* pour le projet ScalaTrain.
