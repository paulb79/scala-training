## Support de cours

- OK, vous devriez avoir un environnement de développement fonctionnel et le code du projet installé.
- Maintenant vous devriez télécharger et décompresser l'archive ZIP [des slides du cours](deck.zip)
- Vous pouvez également consulter [les slides en ligne](index.html)
