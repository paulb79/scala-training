## Installer le plugin ScalaTest pour Eclipse

- Suivez ces instructions si vous souhaitez utiliser Eclipse
- Dans Eclipse, sélectionnez <nobr>*Help > Install New Software*</nobr>
- Choisissez le site de mise à jour *Scala IDE*
- Dépliez *Scala IDE plugins*
- Choisissez *ScalaTest for Scala IDE*
- Cliquez sur *Next >* et suivez l'assistant d'installation
- Redémarrez Eclipse si nécessaire
