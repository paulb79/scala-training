## Installer un IDE

- Nous recommandons d'utiliser l'un des IDEs suivants
  - IntelliJ IDEA
  - Eclipse
