## Ajoutez Activator à votre *PATH*

- Unix: *export PATH=$PATH:/path/to/activator-dir*
- Windows: Mettez à jour le "path" dans les variables d'environnement globales.
