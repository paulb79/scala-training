## Installer *Scala IDE* pour Eclipse II

- Allez dans la console activator pour *scalatrain* et exécutez la commande *eclipse*
```
> eclipse
...
[info] Successfully created Eclipse project files for project(s)
```

- Dans Eclipse, importez le projet *scalatrain* avec <nobr>*Import... > Existing Projects into Workspace*</nobr>
- Sur la page *Import Projects* naviguez jusqu'à votre dossier *scalatrain*
