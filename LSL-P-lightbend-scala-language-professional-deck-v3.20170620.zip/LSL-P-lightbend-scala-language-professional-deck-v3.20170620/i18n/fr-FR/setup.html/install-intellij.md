## Installer IntelliJ IDEA avec le plugin Scala

- Suivez ces instructions si vous souhaitez utiliser IntelliJ IDEA
- Téléchargez et installez [IntelliJ 14 Community Edition](https://www.jetbrains.com/idea/download)
- Après avoir démarré IntelliJ IDEA, allez dans la configuration des plugins pour installer le plugin *Scala*
- Ouvrez le projet *scalatrain* dans IntelliJ
