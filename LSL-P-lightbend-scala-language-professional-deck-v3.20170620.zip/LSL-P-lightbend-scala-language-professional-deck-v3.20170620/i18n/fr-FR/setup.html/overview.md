## Configuration

- Ce document décrit la mise en place de l'environnement de développement et du projet d'étude
- Vous n'êtes pas obligés d'utiliser une configuration spécifique, mais nous vous conseillons d'utiliser les outils suivants :
  - IDE: Eclipse ou IntelliJ, avec le plugin Scala dans les 2 cas
  - Build Tool: Activator
- Le code source du projet d'étude fonctionnera avec tous ces outils.
