## Installer *Scala IDE* pour Eclipse I

- Suivez ces instructions si vous souhaitez utiliser Eclipse
- Vous pouvez télécharger une version pré-packagée et pré-configurée de *Scala IDE* pour votre plateforme depuis  [scala-ide.org/download/sdk.html](http://scala-ide.org/download/sdk.html)
- Vous pouvez également utiliser un version d'éclipse déjà installée:
    - Utilisez le site de mise à jour suivant pour installer la dernière version du plugin *Scala IDE*:
    - Eclipse 4.4 (Luna): <nobr>[download.scala-ide.org/sdk/lithium/e44/scala211/stable/site](http://download.scala-ide.org/sdk/lithium/e44/scala211/stable/site)</nobr>
    - Eclipse 3.8 - 4.3 (Juno et Kepler): <nobr>[download.scala-ide.org/sdk/lithium/e38/scala211/stable/site](http://download.scala-ide.org/sdk/lithium/e38/scala211/stable/site)</nobr>
