## Installer Activator

- Téléchargez Activator 1.3.2  [ici](http://downloads.lightbend.com/typesafe-activator/1.3.2/typesafe-activator-1.3.2.zip)
- Décompressez *typesafe-activator-1.3.2.zip* sur votre disque local
