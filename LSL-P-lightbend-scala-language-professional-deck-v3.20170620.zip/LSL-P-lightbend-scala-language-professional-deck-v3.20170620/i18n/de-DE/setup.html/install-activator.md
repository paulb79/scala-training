## Installiere Activator

- Lade Activator 1.3.2 von [hier](http://downloads.lightbend.com/typesafe-activator/1.3.2/typesafe-activator-1.3.2.zip) herunter
- Extrahiere *typesafe-activator-1.3.2.zip* auf deiner lokalen Festplatte