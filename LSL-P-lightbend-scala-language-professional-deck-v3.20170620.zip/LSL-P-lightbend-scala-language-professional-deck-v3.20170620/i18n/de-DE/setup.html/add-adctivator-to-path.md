## Activator zum PATH hinzufügen

- Unix: *export PATH=$PATH:/path/to/activator-dir*
- Windows: Aktualisiere den Pfad in den globalen Umgebungsvariablen