##Installiere ScalaTrain Code Projekt
- Lade die [ScalaTrain ZIP-Datei](scalatrain.zip) herunter
- Extrahiere *scalatrain.zip* auf deiner lokalen Festplatte
- *cd* zum neuen *scalatrain* Verzeichnis