## Setup

- Dieses Dokument beschreibt, wie man seine Entwicklungsumgebung mit dem Source-Code Projekt einrichtet
- Wir empfehlen folgende Tools zu nutzen:
  - IDE: Eclipse oder IntelliJ, beide mit Scala Plugin
  - Build Tool: Activator
- Das Source-Code Projekt funktioniert mit beiden IDEs
