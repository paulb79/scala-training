##ScalaTrain Case Study

![ScalaTrain](images/scala-train.jpeg "scala-train")

- Dieser Kurs beinhaltet viele Übungen
- Das Projekt für die Übungen ist ein Reiseplaner für Züge, deshalb der Name **ScalaTrain**
- Wir werden in diesem Kurs ScalaTrain von Grund auf implementieren
- Der **Advanced Scala** Kurs wird an die Übungen in diesem Kurs anknüpfen