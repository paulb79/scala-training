# Fast Track to Scala

##Slide deck for the *Fast Track to Scala* training course from Lightbend.

This slide deck is based on [reveal.js](https://github.com/typesafe-training/reveal.js)

If you find errors or would like to suggest improvements, please create an issue or even better, a pull request.


## License

Copyright 2016 Lightbend, Inc. All rights reserved.

Unless otherwise agreed, training materials may only be used for educational and reference purposes by individual named participants in a training course offered by Lightbend or a Lightbend training partner. Unauthorized reproduction, redistribution, or use of this material is prohibited.
