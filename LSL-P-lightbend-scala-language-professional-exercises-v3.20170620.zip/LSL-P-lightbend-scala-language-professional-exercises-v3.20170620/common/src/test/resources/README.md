Lightbend Scala Language - Professional / Lightbend Scala Language - Expert

Please start sbt, run the 'man' or 'man e' command and follow the provided instructions
