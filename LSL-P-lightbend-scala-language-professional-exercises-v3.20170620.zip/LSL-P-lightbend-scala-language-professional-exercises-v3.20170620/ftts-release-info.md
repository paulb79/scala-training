# Release Info for Lightbend Scala Language - Professional (formerly FTTS Fast Track to Scala)

## 2.0.0
### released Feb 2017
| Scala  | Java | Akka  | Akka HTTP | Play  | Lagom  |  Prod Suite |  FDP  |   sbt   | ScalaTest |
|:-------|:-----|:------|:----------|:------|:-------|:------------|:------|:--------|:----------|
| 2.11.8 |8     |       |           |2.5.10 |        |             |       |0.13.13  |3.0.0      |
- the main change to v2.0.0 is switch from koan/groll to the new course management system
- this required changes to exercise code and instructions on how to navigate
- also slides have been changed to reflect the new system
