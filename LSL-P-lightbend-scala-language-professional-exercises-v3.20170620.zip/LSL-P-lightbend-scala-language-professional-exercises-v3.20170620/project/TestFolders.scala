package sbtstudent

object TestFolders {
  val testFolders = List("src/test")
}
       